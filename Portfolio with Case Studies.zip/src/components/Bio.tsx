import { Code2, Figma, Palette, Zap } from "lucide-react";

export function Bio() {
  const skills = [
    {
      icon: Palette,
      title: "UI/UX Design",
      description: "Creating intuitive and visually appealing interfaces with user-centered design principles."
    },
    {
      icon: Code2,
      title: "Front-End Development",
      description: "Building responsive, performant web applications with modern technologies."
    },
    {
      icon: Figma,
      title: "Prototyping",
      description: "Rapid prototyping and design systems to streamline product development."
    },
    {
      icon: Zap,
      title: "Performance",
      description: "Optimizing for speed and accessibility to deliver exceptional user experiences."
    }
  ];

  return (
    <section className="py-20 px-4 bg-white">
      <div className="max-w-6xl mx-auto">
        <div className="grid md:grid-cols-2 gap-12 items-center mb-16">
          <div>
            <h2 className="mb-6">About Me</h2>
            <p className="text-slate-600 mb-4">
              Hi, I'm a passionate designer and developer with over 5 years of experience creating digital products 
              that make a difference. I bridge the gap between design and development, ensuring every project is 
              both beautiful and functional.
            </p>
            <p className="text-slate-600 mb-4">
              My approach combines strategic thinking with creative execution. I believe that great design is 
              invisible—it simply works. Whether I'm wireframing a new feature or writing clean code, I'm always 
              focused on delivering value to users and stakeholders.
            </p>
            <p className="text-slate-600">
              When I'm not designing or coding, you'll find me exploring the latest design trends, contributing 
              to open-source projects, or mentoring aspiring designers.
            </p>
          </div>
          <div className="bg-gradient-to-br from-slate-100 to-slate-200 rounded-2xl p-8 aspect-square flex items-center justify-center">
            <div className="text-center">
              <div className="w-32 h-32 bg-slate-900 rounded-full mx-auto mb-4"></div>
              <p className="text-slate-700">Alex Morgan</p>
              <p className="text-slate-500">San Francisco, CA</p>
            </div>
          </div>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {skills.map((skill, index) => (
            <div key={index} className="p-6 bg-slate-50 rounded-xl hover:bg-slate-100 transition-colors">
              <skill.icon className="w-10 h-10 text-slate-900 mb-4" />
              <h3 className="mb-2">{skill.title}</h3>
              <p className="text-slate-600">{skill.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
