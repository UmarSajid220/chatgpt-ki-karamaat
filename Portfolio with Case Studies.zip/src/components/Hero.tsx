import { ArrowDown } from "lucide-react";

export function Hero() {
  return (
    <section className="min-h-screen flex flex-col justify-center items-center px-4 py-20 bg-gradient-to-br from-slate-50 to-slate-100">
      <div className="max-w-4xl text-center">
        <div className="inline-block px-4 py-2 bg-slate-900 text-slate-50 rounded-full mb-6">
          Available for freelance
        </div>
        <h1 className="mb-6">
          UI/UX Designer & <br />
          Front-End Developer
        </h1>
        <p className="text-slate-600 mb-8 max-w-2xl mx-auto">
          Crafting beautiful, user-centered digital experiences with a perfect blend of design aesthetics and technical expertise. 
          Transforming ideas into intuitive interfaces that users love.
        </p>
        <div className="flex gap-4 justify-center flex-wrap">
          <button className="px-6 py-3 bg-slate-900 text-slate-50 rounded-lg hover:bg-slate-800 transition-colors">
            View My Work
          </button>
          <button className="px-6 py-3 border-2 border-slate-900 text-slate-900 rounded-lg hover:bg-slate-900 hover:text-slate-50 transition-colors">
            Get In Touch
          </button>
        </div>
      </div>
      <div className="absolute bottom-8 animate-bounce">
        <ArrowDown className="w-6 h-6 text-slate-400" />
      </div>
    </section>
  );
}
