import { ArrowRight } from "lucide-react";
import { ImageWithFallback } from "./figma/ImageWithFallback";

interface CaseStudy {
  title: string;
  category: string;
  description: string;
  image: string;
  tags: string[];
  year: string;
}

export function CaseStudies() {
  const caseStudies: CaseStudy[] = [
    {
      title: "E-Commerce Platform Redesign",
      category: "UI/UX Design & Development",
      description: "A complete overhaul of an e-commerce platform, improving conversion rates by 45% through enhanced user experience and streamlined checkout process.",
      image: "https://images.unsplash.com/photo-1676792519027-7c42006d7b4a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb2Rlcm4lMjB3ZWJzaXRlJTIwZGVzaWdufGVufDF8fHx8MTc2MzAzNzU0Nnww&ixlib=rb-4.1.0&q=80&w=1080",
      tags: ["UI/UX", "React", "Figma"],
      year: "2024"
    },
    {
      title: "Health & Wellness Mobile App",
      category: "Product Design",
      description: "Designed and prototyped a fitness tracking app focusing on mindfulness and holistic wellness. Featured on Product Hunt's top 10 health apps.",
      image: "https://images.unsplash.com/photo-1760037028485-d00dd2b8f6f0?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmaXRuZXNzJTIwYXBwJTIwZGVzaWdufGVufDF8fHx8MTc2MzA1NDU2OHww&ixlib=rb-4.1.0&q=80&w=1080",
      tags: ["Mobile", "Prototyping", "User Research"],
      year: "2024"
    },
    {
      title: "SaaS Dashboard Interface",
      category: "UI Design & Front-End",
      description: "Created a comprehensive dashboard for a B2B analytics platform, handling complex data visualization with an intuitive, clean interface.",
      image: "https://images.unsplash.com/photo-1592773307163-962d25055c3c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxlY29tbWVyY2UlMjBkYXNoYm9hcmR8ZW58MXx8fHwxNzYzMDI2NTc4fDA&ixlib=rb-4.1.0&q=80&w=1080",
      tags: ["Dashboard", "Data Viz", "TypeScript"],
      year: "2023"
    },
    {
      title: "Banking App Redesign",
      category: "Mobile Design",
      description: "Modernized a legacy banking application with focus on accessibility and security, reducing support tickets by 60%.",
      image: "https://images.unsplash.com/photo-1605108222700-0d605d9ebafe?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb2JpbGUlMjBhcHAlMjBpbnRlcmZhY2V8ZW58MXx8fHwxNzYzMDYyMDgwfDA&ixlib=rb-4.1.0&q=80&w=1080",
      tags: ["Mobile", "Accessibility", "Design System"],
      year: "2023"
    }
  ];

  return (
    <section className="py-20 px-4 bg-slate-50">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-12">
          <h2 className="mb-4">Case Studies</h2>
          <p className="text-slate-600 max-w-2xl mx-auto">
            Explore my recent projects where design meets functionality. Each case study demonstrates 
            problem-solving, creativity, and measurable impact.
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-8">
          {caseStudies.map((study, index) => (
            <div 
              key={index}
              className="group bg-white rounded-2xl overflow-hidden hover:shadow-2xl transition-all duration-300"
            >
              <div className="relative aspect-video overflow-hidden bg-slate-200">
                <ImageWithFallback
                  src={study.image}
                  alt={study.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                />
                <div className="absolute top-4 right-4 bg-white px-3 py-1 rounded-full">
                  {study.year}
                </div>
              </div>
              <div className="p-6">
                <p className="text-slate-500 mb-2">{study.category}</p>
                <h3 className="mb-3">{study.title}</h3>
                <p className="text-slate-600 mb-4">{study.description}</p>
                <div className="flex flex-wrap gap-2 mb-4">
                  {study.tags.map((tag, tagIndex) => (
                    <span 
                      key={tagIndex}
                      className="px-3 py-1 bg-slate-100 text-slate-700 rounded-full"
                    >
                      {tag}
                    </span>
                  ))}
                </div>
                <button className="flex items-center gap-2 text-slate-900 group-hover:gap-3 transition-all">
                  View Case Study
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
