import { Github, Linkedin, Mail, Twitter } from "lucide-react";

export function Footer() {
  return (
    <footer className="py-12 px-4 bg-slate-900 text-slate-50">
      <div className="max-w-6xl mx-auto">
        <div className="grid md:grid-cols-3 gap-8 mb-8">
          <div>
            <h3 className="mb-4 text-slate-50">Let's Work Together</h3>
            <p className="text-slate-400">
              I'm always open to discussing new projects, creative ideas, or opportunities to be part of your vision.
            </p>
          </div>
          <div>
            <h4 className="mb-4 text-slate-50">Quick Links</h4>
            <ul className="space-y-2 text-slate-400">
              <li><a href="#" className="hover:text-slate-50 transition-colors">About</a></li>
              <li><a href="#" className="hover:text-slate-50 transition-colors">Case Studies</a></li>
              <li><a href="#" className="hover:text-slate-50 transition-colors">Services</a></li>
              <li><a href="#" className="hover:text-slate-50 transition-colors">Contact</a></li>
            </ul>
          </div>
          <div>
            <h4 className="mb-4 text-slate-50">Connect</h4>
            <div className="flex gap-4">
              <a href="#" className="p-2 bg-slate-800 rounded-lg hover:bg-slate-700 transition-colors">
                <Linkedin className="w-5 h-5" />
              </a>
              <a href="#" className="p-2 bg-slate-800 rounded-lg hover:bg-slate-700 transition-colors">
                <Github className="w-5 h-5" />
              </a>
              <a href="#" className="p-2 bg-slate-800 rounded-lg hover:bg-slate-700 transition-colors">
                <Twitter className="w-5 h-5" />
              </a>
              <a href="#" className="p-2 bg-slate-800 rounded-lg hover:bg-slate-700 transition-colors">
                <Mail className="w-5 h-5" />
              </a>
            </div>
          </div>
        </div>
        <div className="pt-8 border-t border-slate-800 text-center text-slate-400">
          <p>© 2024 Alex Morgan. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
}
