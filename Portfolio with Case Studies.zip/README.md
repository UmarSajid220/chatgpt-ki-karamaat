
  # Portfolio with Case Studies

  This is a code bundle for Portfolio with Case Studies. The original project is available at https://www.figma.com/design/yFTPw4qgHjBizbmFeAZLTl/Portfolio-with-Case-Studies.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  